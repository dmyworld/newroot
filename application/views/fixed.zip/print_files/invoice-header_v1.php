<table width="100%" border="0" >
  
 
 
  <tr>
    <th class="daashan" width="23%" align="left" valign="middle" scope="row">
    
               <?php echo '<strong>' . $invoice['name'] . '</strong><br>';
               
                if ($invoice['company']) echo $invoice['company'] . '<br>';
                echo $invoice['address'] . '<br>' . $invoice['city'] . ', ' . $invoice['region'] . '<br>' . $invoice['country'] . '-' . $invoice['postbox'] . '<br>' . $this->lang->line('Phone') . ': ' . $invoice['phone'] . '<br>' . $this->lang->line('Email') . ' : ' . $invoice['email'];
                if ($invoice['taxid']) echo '<br>' . $this->lang->line('Tax') . ' ID: ' . $invoice['taxid'];
               
                if (is_array($c_custom_fields)) {
                    echo '<br>';
                    foreach ($c_custom_fields as $row) {
                        echo $row['name'] . ': ' . $row['data'] . '<br>';
                    }
                }
                ?>
               
        <?php if (@$invoice['name_s']) { ?>
           
                 
                    <?php echo '<strong>' . $this->lang->line('Shipping Address') . '</strong>:<br>';
                    echo $invoice['name_s'] . '<br>';
                    echo $invoice['address_s'] . '<br>' . $invoice['city_s'] . ', ' . $invoice['region_s'] . '<br>' . $invoice['country_s'] . '-' . $invoice['postbox_s'] . '<br> ' . $this->lang->line('Phone') . ': ' . $invoice['phone_s'] . '<br> ' . $this->lang->line('Email') . ': ' . $invoice['email_s'];
                    ?>
                
         
        <?php } ?></th>
        
        
    <th class="daashanabc" width="40%" align="center" valign="top" scope="row">
         <img src="<?php $loc = location($invoice['loc']);
            echo FCPATH . 'userfiles/company/' . $loc['logo'] ?>"
                 class="top_logo"> <h1><strong>හපුආරච්චි ලී මෝල ලී වෙළඳසැල</strong></h1>    <br>
        
        නො. 01, ද ෆිනෑන්ස් වත්ත, විළිඹුල, හේනේගම.<br>
    ටෙලි : 033-2267206, ෆැක්ස් :033-2267878 <br>ඊ-මෙල්  : hapuarachchism@sltnet.lk 
    
 <?   if ($invoice['taxid']) echo '<br>Our Texas No: 662941794-7000' ; ?>
   
    
    
    
    
    </th>   
    
    
    
    <th class="daashanabc"  width="23%" align="left"  valign="middle" scope="row">
        
                     බිල් අංකය.....:
                     <?= $general['prefix'] . ' ' . $invoice['tid'] ?> <br>
                     
                     දිනය...........:
                   <?php echo dateformat($invoice['invoicedate']) ?><br>
              
               
                     ණය දිනය......:
                    <?php echo dateformat($invoice['invoiceduedate']) ?>
                
                <?php if ($invoice['refer']) { ?><br>
                    <?php echo $this->lang->line('Reference') ?>
                        <?php echo $invoice['refer'] ?>
                    
                <?php } ?> 
              
  </tr>
</table>




 <br>
 
    <br>
<br><br><br><br><br><br>
